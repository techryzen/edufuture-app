# Empty init file for models package 

# Models package
from app.models.user import User
from app.models.blog import Blog
from app.models.notification import Notification 