from app import create_app
import os
import argparse

# Parse command line arguments
parser = argparse.ArgumentParser(description='Run the Flask application')
parser.add_argument('--port', type=int, default=8080, help='Port to run the app on')
args = parser.parse_args()

# Get configuration mode from environment or default to development
config_name = os.environ.get('FLASK_ENV', 'development')
app = create_app(config_name)

if __name__ == '__main__':
    app.run(debug=app.config['DEBUG'], port=args.port) 