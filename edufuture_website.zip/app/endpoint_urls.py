# Blog endpoints
BLOG_DETAIL = 'blog.blog_detail'
BLOG_LIST = 'blog.blog_list'

# Admin endpoints
ADMIN_DASHBOARD = 'admin.dashboard'
ADMIN_USER_LIST = 'admin.user_list'
ADMIN_EDIT_USER = 'admin.edit_user'
ADMIN_BLOG_LIST = 'admin.blog_list'
ADMIN_MEDIA_LIBRARY = 'admin.media_library'
ADMIN_ANALYTICS = 'admin.analytics'
ADMIN_SETTINGS = 'admin.settings'
ADMIN_NOTIFICATIONS = 'admin.notifications' 